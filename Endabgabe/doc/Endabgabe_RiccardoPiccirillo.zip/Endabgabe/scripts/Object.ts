namespace endabgabe {
    export class Object {
        xPos: number;
        yPos: number;
        color: string;

        constructor() {
            //epmty
        }

        update(): void {
            //epmty
        }

        draw(): void {
            //epmty
        }


    }
}