"use strict";
var endabgabe;
(function (endabgabe) {
    class Object {
        constructor() {
            //epmty
        }
        update() {
            //epmty
        }
        draw() {
            //epmty
        }
    }
    endabgabe.Object = Object;
})(endabgabe || (endabgabe = {}));
//# sourceMappingURL=Object.js.map